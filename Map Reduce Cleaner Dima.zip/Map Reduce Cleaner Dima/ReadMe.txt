1. Running Environment --Hadoop Cluster
2. Where to run the code ? -- Edge Node of Hadoop Cluster
3. Steps to Run the Code:

a) Place the jar in the Hadoop Edge Node
b) Make HDFS Directories : 1. hdfs dfs mkdir /user/XYZ/input/ 2. hdfs dfs mkdir /user/XYZ/output/
c) Put input.csv to HDFS Directory :  hdfs dfs -put input.csv /user/XYZ/input/ 

Map Reduce works in Hadoop Environment & HDFS Storage System that's why we are creating this.

d) Type command :
hadoop jar mapReducerCleanerDima.jar mapReducerCleanerDima.Driver /user/sm185488/input/input.csv /user/sm185488/output/

The command uses two user argument 1. Path of Input File directory
2. Path of Output File Directory


4. The code should run fine without any erros and placing the output file in the output directory


