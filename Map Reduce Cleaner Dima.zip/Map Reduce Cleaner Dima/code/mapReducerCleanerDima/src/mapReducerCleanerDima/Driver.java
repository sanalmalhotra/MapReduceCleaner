package mapReducerCleanerDima;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/*This class is responsible for running map reduce job*/
//This is the main Class

/**
 * @author: Sanal Malhotra
 */

public class Driver extends Configured implements Tool {

public static void main(String[] args) throws Exception {
int exitCode = ToolRunner.run(new Driver(), args);
System.exit(exitCode);
}

public int run(String[] args) throws Exception {
if (args.length != 2) {
System.err.printf("Usage: %s [generic options] <input> <output>\n",
getClass().getSimpleName());
ToolRunner.printGenericCommandUsage(System.err);
return -1;
}

Job job = new org.apache.hadoop.mapreduce.Job();
job.setJarByClass(Driver.class);
job.setJobName("Driver App");

FileInputFormat.addInputPath(job, new Path(args[0]));
// Added to delete the Output folder if already exists
Configuration conf = job.getConfiguration();
FileSystem.get(conf).delete(new Path(args[1]), true);
FileOutputFormat.setOutputPath(job, new Path(args[1]));

job.setOutputKeyClass(Text.class);
job.setOutputValueClass(Text.class);
job.setOutputFormatClass(TextOutputFormat.class);
job.setMapperClass(MapperApp.class);
job.setReducerClass(ReducerApp.class);

// Sets reducer tasks to 0
job.setNumReduceTasks(0);

int returnValue = job.waitForCompletion(true) ? 0:1;
System.out.println("job.isSuccessful" + job.isSuccessful());
return returnValue;

}
}
