package mapReducerCleanerDima;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperApp extends Mapper<Object, Text, Text, Text> {

@Override
protected void map(Object key, Text value, Context context)
throws IOException, InterruptedException {

String[] tokens = value.toString().split(",");
//Defining the columns in the excel sheet where we want to apply the logic. We are concerned about col2 and col3
String col0 = tokens[0];
String col1 = tokens[1];
String col2 = tokens[2];
String col3 = tokens[3];
String col4 = tokens[4];
String col5 = tokens[5];
String col6 = tokens[6];
String col7 = tokens[7];
String col8 = tokens[8];
String col9 = tokens[9];
String col10 = tokens[10];
String col11 = tokens[11];
String col12 = tokens[12];
String col13 = tokens[13];
String col14 = tokens[14];
String col15 = tokens[15];
String col16 = tokens[16];
String col17 = tokens[17];
String col18 = tokens[18];
String col19 = tokens[19];
String col20 = tokens[20];
String col21 = tokens[21];
String col22 = tokens[22];
String col23 = tokens[23];
String col24 = tokens[24];



String avgcol2= "30";
String avgcol3= "23";

//Writing the cleaned data in a new file which will have cleaned col 2 and col3
//NaN will be cleaned with the average Temperature values
	
context.write(new Text(col0), new Text(col1),new Text(col2.replace("NaN",avgcol2)), new Text(col3.replace("NaN",avgcol3)), new Text(col4), new Text(col5), new Text(col6), new Text(col7), new Text(col8), new Text(col9), new Text(col10), new Text(col11), new Text(col12), new Text(col3), new Text(col4), new Text(col15), new Text(col16), new Text(col17), new Text(col18), new Text(col19), new Text(col20), new Text(col21), new Text(col22), new Text(col23), new Text(col24));
}
}
