package mapReducerCleanerDima;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperApp extends Mapper<Object, Text, Text, Text> {

@Override
protected void map(Object key, Text value, Context context)
throws IOException, InterruptedException {

String[] tokens = value.toString().split(",");
//Defining the columns in the excel sheet where we want to apply the logic. We are concerned about col2 and col3
String col0 = tokens[0];
String col1 = tokens[1];
String col2 = tokens[2];
String col3 = tokens[3];
String avgcol2= "30";
String avgcol3= "23";

//Writing the cleaned data in a new file which will have cleaned col 2 and col3
//NaN will be cleaned with the average Temperature values
	
context.write(new Text(col2.replace("NaN",avgcol2)), new Text(col3.replace("NaN",avgcol3)));
}
}
