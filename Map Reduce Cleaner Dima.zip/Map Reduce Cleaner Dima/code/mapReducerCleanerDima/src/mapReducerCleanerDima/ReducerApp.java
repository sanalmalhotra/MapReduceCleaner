package mapReducerCleanerDima;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerApp extends Reducer<IntWritable, IntWritable, Text, Text> {

@Override
public void reduce(IntWritable key, Iterable<IntWritable> values, Context context)
throws IOException, InterruptedException {
//Defining the columns in the excel sheet where we want to apply the logic
String col2 = "";
String col3 = "";

Iterator itr = values.iterator();
while (itr.hasNext()){
col2 = key.toString();
col3 = itr.next().toString();

//Writing the cleaned data in a new file which will have cleaned col 2 and col3
//NaN will be cleaned with the average Temperature values
	
context.write(new Text(col2), new Text(col3));
}
}

}