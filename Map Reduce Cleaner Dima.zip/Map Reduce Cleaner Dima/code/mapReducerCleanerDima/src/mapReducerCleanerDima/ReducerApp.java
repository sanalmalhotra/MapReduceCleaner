package mapReducerCleanerDima;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerApp extends Reducer<IntWritable, IntWritable, Text, Text> {

@Override
public void reduce(IntWritable key, Iterable<IntWritable> values, Context context)
throws IOException, InterruptedException {
//Defining the columns in the excel sheet where we want to apply the logic
String col0 = "";
String col1 = "";
String col2 = "";
String col3 = "";
String col4 = "";
String col5 = "";
String col6 = "";
String col7 = "";
String col8 = "";
String col9 = "",
String col10 ="",
String col11 ="",
String col12 ="",
String col13 ="",
String col14 ="",
String col15 ="",
String col16 ="",
String col17 ="",
String col18 ="",
String col19 ="",
String col20 ="",
String col21 ="",
String col22 ="",
String col23 ="",
String col24 ="",
Iterator itr = values.iterator();
while (itr.hasNext()){
col0=key.toString();
col1=itr.next().toString();
col2=itr.next().toString();
col3=itr.next().toString();
col4=itr.next().toString();
col5=itr.next().toString();
col6=itr.next().toString();
col7=itr.next().toString();
col8=itr.next().toString();
col9=itr.next().toString();
col10=itr.next().toString();
col11=itr.next().toString();
col12=itr.next().toString();
col13=itr.next().toString();
col14=itr.next().toString();
col15=itr.next().toString();
col16=itr.next().toString();
col17=itr.next().toString();
col18=itr.next().toString();
col19=itr.next().toString();
col20=itr.next().toString();
col21=itr.next().toString();
col22=itr.next().toString();
col23=itr.next().toString();
col24=itr.next().toString();
//Writing the cleaned data in a new file which will have cleaned col 2 and col3
//NaN will be cleaned with the average Temperature values
	
context. write(new Text(col0), new Text(col1),new Text(col2.replace("NaN",avgcol2)), new Text(col3.replace("NaN",avgcol3)), new Text(col4), new Text(col5), new Text(col6), new Text(col7), new Text(col8), new Text(col9), new Text(col10), new Text(col11), new Text(col12), new Text(col3), new Text(col4), new Text(col15), new Text(col16), new Text(col17), new Text(col18), new Text(col19), new Text(col20), new Text(col21), new Text(col22), new Text(col23), new Text(col24));
 
}
}

}
